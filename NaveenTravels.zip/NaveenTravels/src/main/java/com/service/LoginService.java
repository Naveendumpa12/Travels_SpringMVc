package com.service;

import com.entity.User;

public interface LoginService {
	
	void signUpUser(User user);
	
}
